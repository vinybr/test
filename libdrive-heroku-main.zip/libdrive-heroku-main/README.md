<a href="#">
  <h3 align="center">
    <img src="https://i.ibb.co/HVB5Dw1/lib-Drive-Header.png" width="600px" />
  </h3>
</a>
<p align="center">
  
  </a>
  <a href="https://github.com/libDrive/libDrive/releases/latest">
    <img src="https://img.shields.io/github/v/release/libDrive/libDrive?color=%234197fe&style=for-the-badge" />
  </a>
</p>
<p align="center">
  <a href="https://heroku.com/deploy?template=https://github.com/samucamg/libdrive-heroku/">
    <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="200" />
  </a>
</p>

</p>

# O que é esse Repositório?

libDrive é um gerenciador e indexador de biblioteca de mídia do Google Drive, semelhante ao Plex, que organiza a mídia do Google Drive para oferecer uma experiência intuitiva e amigável.

Esse projeto foi criado e depois abandonado por @eliasbenb, então decidi continuar o projeto para não ser esquecido..

Este repositório (<https://github.com/samucamg/libdrive-heroku>) armazena o código-fonte para a implantação [Heroku] (https://heroku.com) de libDrive.
## Source code

- [libDrive/libDrive](https://github.com/libDrive/libDrive)
- [libDrive/server](https://github.com/libDrive/server)
- [libDrive/web](https://github.com/libDrive/web)
- [libDrive/cloudflare](https://github.com/libDrive/cloudflare)
- [libDrive/heroku](https://github.com/libDrive/heroku)
- [libDrive/config](https://github.com/libDrive/config)
